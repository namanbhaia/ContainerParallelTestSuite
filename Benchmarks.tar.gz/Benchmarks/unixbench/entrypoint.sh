#!/bin/bash

echo "Container for test running"
cd byte-unixbench/UnixBench
export UB_OUTPUT_CSV="true"
make

mkdir results
numRuns="$1"
echo "NumRuns received is: $numRuns"
x=1
while [ $x -le $numRuns ]
do
	echo "In same container, running test: $x"
	./Run
	x=$(( $x + 1 ))
done
echo "Tests runs complete!"
python3 mergeCSV.py
