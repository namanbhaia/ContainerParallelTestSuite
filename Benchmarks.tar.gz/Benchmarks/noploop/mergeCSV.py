import glob
import pandas as pd
import datetime
import os

def extractValues(x):
	vals = x.split(' ');
	vals = [i for i in vals if i];
	return vals

file = 'temp.txt'
df = pd.read_csv(file, sep=" ", header=None)
print (df)
data = pd.DataFrame(columns=['TestNum', 'real', 'user', 'sys'])
for i in range(len(df)):
	val = df.iloc[i, 1]
	col = df.iloc[i, 0]
	print(str(i%3) + ":" + str(i//3) + ":" + col)
	data.loc[i//3, col] = val
	data.loc[i//3, 'TestNum'] = i//3 + 1

dateTime = datetime.datetime.now();
dateTimeStr = dateTime.strftime("%d-%m-%Y_%H-%M-%S")
name = os.getcwd() + "finalResults/NoploopRun_" + dateTimeStr + ".csv";
data.to_csv(name, index=False)
print("Concatenated file is stored at: ", name);
